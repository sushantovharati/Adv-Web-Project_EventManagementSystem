import Link from "next/link";
import {
  CalendarDays,
  Users,
  CheckCircle,
  Clock,
  MapPin,
  Calendar,
} from "lucide-react";
import Navbar from "@/components/layout/Navbar";

export default function LandingPage() {
  return (
    <>
    <Navbar />
    <main className="w-full">

      {/* ================= HERO SECTION ================= */}
      <section className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-6 py-32 text-center">
          <h1 className="text-4xl md:text-5xl font-bold">
            Welcome to CampusEvents
          </h1>

          <p className="mt-6 text-lg max-w-3xl mx-auto opacity-90">
            Your all-in-one platform for managing events, tracking participants,
            and creating memorable experiences in real time.
          </p>

          <div className="mt-10 flex justify-center gap-4">
            <Link
              href="/organizer/register"
              className="bg-white text-blue-600 font-semibold px-8 py-4 rounded-xl hover:bg-gray-100 transition"
            >
              Get Started
            </Link>

            <Link
              href="/organizer/login"
              className="border border-white text-white font-semibold px-8 py-4 rounded-xl hover:bg-white hover:text-blue-600 transition"
            >
              Login
            </Link>
          </div>
        </div>
      </section>

      {/* ================= WHY CHOOSE ================= */}
      <section className="bg-white py-24">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Why Choose EventHub?
          </h2>

          <p className="mt-4 text-gray-600">
            Powerful real-time features designed for smooth event management
          </p>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard
              icon={<CalendarDays size={22} />}
              title="Easy Event Management"
              text="Create, update, and manage events instantly with live status tracking and real-time changes visible to participants."
            />

            <FeatureCard
              icon={<Users size={22} />}
              title="Real-time Participant Tracking"
              text="Monitor registrations, attendance counts, and participant activity as it happens without manual refresh."
            />

            <FeatureCard
              icon={<CheckCircle size={22} />}
              title="Live Event Updates"
              text="Automatically reflect schedule changes, attendee limits, and event completion status across the platform."
            />
          </div>
        </div>
      </section>

      {/* ================= UPCOMING EVENTS ================= */}
      {/* <section className="bg-[#EEF4FF] py-24">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Upcoming Events
          </h2>

          <p className="mt-4 text-gray-600">
            Join us for these exciting events
          </p>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <EventCard
              title="Tech Conference 2026"
              desc="Annual technology conference featuring industry leaders and innovative solutions"
              date="15/02/2026"
              time="09:00"
              location="San Francisco Convention Center"
              attendees="500 attendees"
            />

            <EventCard
              title="React Workshop"
              desc="Hands-on workshop covering advanced React patterns and best practices"
              date="20/01/2026"
              time="14:00"
              location="Tech Hub Downtown"
              attendees="50 attendees"
            />

            <EventCard
              title="Team Building Social"
              desc="Fun social event for team bonding and networking"
              date="25/01/2026"
              time="19:00"
              location="Rooftop Lounge"
              attendees="75 attendees"
            />
          </div>

          <div className="mt-16">
            <Link
              href="/events"
              className="inline-flex items-center gap-2 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition"
            >
              View All Events →
            </Link>
          </div>
        </div>
      </section> */}

      <section className="bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 text-white py-28">
        <div className="max-w-4xl mx-auto text-center px-6">
          <h2 className="text-3xl md:text-4xl font-bold">
            Ready to Get Started?
          </h2>

          <p className="mt-4 text-lg opacity-90">
            Join thousands of event organizers who trust EventHub to manage
            events in real time.
          </p>

          <Link
            href="/organizer/register"
            className="mt-10 inline-block bg-white text-blue-600 px-10 py-4 rounded-xl font-semibold hover:bg-gray-100 transition"
          >
            Create Your Account
          </Link>
        </div>
      </section>
    </main>
    </>
  );
}

/* ================= COMPONENTS ================= */

function FeatureCard({
  icon,
  title,
  text,
}: {
  icon: React.ReactNode;
  title: string;
  text: string;
}) {
  return (
    <div className="bg-[#F4F7FF] rounded-3xl p-8 text-left">
      <div className="h-12 w-12 bg-blue-600 text-white rounded-xl flex items-center justify-center">
        {icon}
      </div>
      <h3 className="mt-6 text-xl font-semibold text-gray-900">
        {title}
      </h3>
      <p className="mt-3 text-gray-600 leading-relaxed">
        {text}
      </p>
    </div>
  );
}

function EventCard({
  title,
  desc,
  date,
  time,
  location,
  attendees,
}: {
  title: string;
  desc: string;
  date: string;
  time: string;
  location: string;
  attendees: string;
}) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
      <div className="h-1 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 mb-5" />

      <h3 className="text-xl font-semibold text-gray-900">{title}</h3>
      <p className="mt-2 text-gray-600">{desc}</p>

      <div className="mt-4 space-y-2 text-gray-600 text-sm">
        <div className="flex items-center gap-2">
          <Calendar size={16} /> {date}
        </div>
        <div className="flex items-center gap-2">
          <Clock size={16} /> {time}
        </div>
        <div className="flex items-center gap-2">
          <MapPin size={16} /> {location}
        </div>
        <div className="flex items-center gap-2">
          <Users size={16} /> {attendees}
        </div>
      </div>
    </div>
    
  );
}
