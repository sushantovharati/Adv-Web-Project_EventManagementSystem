export default function CreateEventPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Create Event</h1>
      <p className="text-gray-600 mt-2">Form will be added here.</p>
    </div>
  );
}
